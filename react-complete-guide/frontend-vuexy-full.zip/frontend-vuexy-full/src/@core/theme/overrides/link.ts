export default {
  MuiLink: {
    styleOverrides: {
      root: {
        textDecoration: 'none'
      }
    }
  }
}
