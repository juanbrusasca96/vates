// ** Demo Components Imports
import Preview from 'src/views/apps/invoice/preview/Preview'

const InvoicePreview = () => {
  return <Preview id='4987' />
}

export default InvoicePreview
